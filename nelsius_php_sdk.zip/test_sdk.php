<?php

require_once __DIR__ . '/src/NelsiusClient.php';
require_once __DIR__ . '/src/Managers/ChargeManager.php';
require_once __DIR__ . '/src/Managers/CheckoutManager.php';
require_once __DIR__ . '/src/Managers/BalanceManager.php';

use Nelsius\NelsiusClient;

echo "--- Nelsius PHP SDK Test ---\n";

// Configuration (Use a test key from your database)
$apiKey = 'sk_live_L8L1W438xaoBGxTEzD0qBnpkwxrtvJGWKPbVsj88CFhJzrXw69fNPjFEANsDUWPy'; // Validated test key
$baseUrl = 'http://127.0.0.1:8000/api/v1';

try {
    $nelsius = new NelsiusClient($apiKey, [
        'base_url' => $baseUrl
    ]);

    // 1. Get Payment Methods
    echo "\n1. Fetching payment methods...\n";
    $methods = $nelsius->charges->methods();
    echo "Found " . count($methods['data'] ?? []) . " payment methods.\n";

    // 2. Get Balance
    echo "\n2. Fetching balance...\n";
    $balance = $nelsius->balance->get();
    echo "Current Balance: " . ($balance['data']['balance'] ?? '0') . " " . ($balance['data']['currency'] ?? 'XAF') . "\n";

    // 3. Create Checkout Session
    echo "\n3. Creating checkout session...\n";
    $checkout = $nelsius->checkout->createSession([
        'amount' => 5000,
        'currency' => 'XAF',
        'reference' => 'TEST_PHP_REF_' . time(),
        'description' => 'Test PHP SDK Purchase',
        'return_url' => 'https://example.com/success',
        'cancel_url' => 'https://example.com/cancel',
        'customer' => [
            'email' => 'customer@example.com',
            'name' => 'PHP SDK Tester'
        ]
    ]);

    if (isset($checkout['data']['checkout_url'])) {
        echo "Checkout Session Created: " . $checkout['data']['checkout_url'] . "\n";
    } else {
        echo "Checkout Session Creation Failed: " . json_encode($checkout) . "\n";
    }

    // 4. Create Direct Charge (Mental note: might timeout locally)
    echo "\n4. Creating direct charge...\n";
    $charge = $nelsius->charges->create([
        'amount' => 2500,
        'currency' => 'XAF',
        'method' => 'mobile_money',
        'operator' => 'orange',
        'customer_phone' => '690000000',
        'reference' => 'TEST_CHARGE_REF_' . time(),
        'description' => 'Test Direct Charge PHP SDK'
    ]);

    if (isset($charge['data']['charge_id'])) {
        echo "Direct Charge Created: " . $charge['data']['charge_id'] . "\n";
    } else {
        echo "Direct Charge Status: " . ($charge['message'] ?? 'Pending') . "\n";
    }

    echo "\n--- All SDK tests completed successfully (or handled) ---\n";

} catch (\Exception $e) {
    echo "\nERROR: " . $e->getMessage() . "\n";
}
